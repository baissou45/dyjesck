-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:3306
-- Généré le : lun. 13 déc. 2021 à 09:07
-- Version du serveur :  10.3.24-MariaDB-cll-lve
-- Version de PHP : 7.3.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `mainfobi_dyjesck`
--

-- --------------------------------------------------------

--
-- Structure de la table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `titre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `categories`
--

INSERT INTO `categories` (`id`, `titre`, `slug`, `created_at`, `updated_at`) VALUES
(2, 'Batiments', 'batiments', '2021-12-13 18:23:39', '2021-12-13 18:23:39'),
(3, 'Revètement', 'revetement', '2021-12-13 18:24:55', '2021-12-13 18:24:55'),
(4, 'Adduction d\'eau', 'adduction-deau', '2021-12-13 18:25:25', '2021-12-13 18:25:25'),
(5, 'Pavage & Assainissement', 'pavage-assainissement', '2021-12-13 18:26:05', '2021-12-13 18:26:05'),
(6, 'Autres Constructions', 'autres-constructions', '2021-12-13 18:42:54', '2021-12-13 18:42:54');

-- --------------------------------------------------------

--
-- Structure de la table `comments`
--

CREATE TABLE `comments` (
  `id` int(10) UNSIGNED NOT NULL,
  `nom` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mail` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_id` bigint(20) UNSIGNED DEFAULT NULL,
  `comment_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `posts`
--

CREATE TABLE `posts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `titre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` date DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `epingle` tinyint(1) NOT NULL,
  `img` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `img2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `img3` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `img4` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `categorie_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `posts`
--

INSERT INTO `posts` (`id`, `titre`, `date`, `slug`, `description`, `epingle`, `img`, `img2`, `img3`, `img4`, `user_id`, `categorie_id`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'CONSTRUCTION DÉCOLE À ZINVIE', NULL, 'construction-decole-a-zinvie', 'Dans le cardre du projet JAPON 6, nous avons eut à construire un établissement scolaire à ZINVIE', 0, 'postimage/2021_12_13-11:57:45_CONSTRUCTION DÉCOLE À ZINVIE_img.jpg', 'postimage/2021_12_13-11:57:45_CONSTRUCTION DÉCOLE À ZINVIE_imga.jpg', 'postimage/2021_12_13-11:57:45_CONSTRUCTION DÉCOLE À ZINVIE_imgb.jpg', 'postimage/2021_12_13-11:57:45_CONSTRUCTION DÉCOLE À ZINVIE_imgc.jpg', 2, 2, '2021-12-13 18:57:45', '2021-12-13 18:57:45', NULL),
(2, 'Construction d\'école à WOMEY', NULL, 'construction-decole-a-womey', 'Dans le cardre du projet JAPON 6, nous avons eut à construire un établissement scolaire', 0, 'postimage/2021_12_13-12:04:03_Construction d\'école à WOMEY_img.jpg', 'postimage/2021_12_13-12:04:03_Construction d\'école à WOMEY_imga.jpg', 'postimage/2021_12_13-12:04:03_Construction d\'école à WOMEY_imgb.jpg', 'postimage/2021_12_13-12:04:03_Construction d\'école à WOMEY_imgc.jpg', 2, 2, '2021-12-13 19:04:03', '2021-12-13 19:04:03', NULL),
(4, 'Village d\'enfants SOS à Yamoussoukro en Côte d\'Ivoire', NULL, 'village-denfants-sos-a-yamoussoukro-en-cote-divoire', 'Travaux tous corps d\'état : gros œuvres, charpente couverture, plomberie, menuiserie bois et métalliques, revêtements carreaux et souple, étanchéité, peinture etc', 0, 'postimage/2021_12_13-12:06:30_Village d\'enfants SOS à Yamoussoukro en Côte d\'Ivoire_img.crdownload', 'postimage/2021_12_13-12:06:30_Village d\'enfants SOS à Yamoussoukro en Côte d\'Ivoire_imga.crdownload', 'postimage/2021_12_13-12:06:30_Village d\'enfants SOS à Yamoussoukro en Côte d\'Ivoire_imgb.crdownload', 'postimage/2021_12_13-12:06:30_Village d\'enfants SOS à Yamoussoukro en Côte d\'Ivoire_imgc.crdownload', 2, 2, '2021-12-13 19:06:30', '2021-12-13 19:06:30', NULL),
(5, 'Construction Mairie Cotonou', NULL, 'construction-mairie-cotonou', 'Projet de construction de la mairie de Cotonou (Bénin)', 0, 'postimage/2021_12_13-12:11:05_Construction Mairie Cotonou_img.jpg', 'postimage/2021_12_13-12:11:05_Construction Mairie Cotonou_imga.jpg', 'postimage/2021_12_13-12:11:05_Construction Mairie Cotonou_imgb.jpg', 'postimage/2021_12_13-12:11:05_Construction Mairie Cotonou_imgc.jpg', 2, 2, '2021-12-13 19:11:05', '2021-12-13 19:11:05', NULL),
(6, 'Abuja (Tout corps d\'état)2', NULL, 'abuja-tout-corps-detat2', 'Projet de construction de l\'Ambassade du Bénin au Nigéria. \r\nTravaux de revêtement multiforme.', 0, 'postimage/2021_12_13-12:13:24_Abuja (Tout corps d\'état)2_img.jpg', 'postimage/2021_12_13-12:13:24_Abuja (Tout corps d\'état)2_imga.jpg', 'postimage/2021_12_13-12:13:24_Abuja (Tout corps d\'état)2_imgb.jpg', 'postimage/2021_12_13-12:13:24_Abuja (Tout corps d\'état)2_imgc.jpg', 1, 3, '2021-12-13 19:13:24', '2021-12-13 19:13:24', NULL),
(7, 'Abuja (Tout corps d\'état)', NULL, 'abuja-tout-corps-detat', 'Projet de construction de l\'Ambassade du Bénin au Nigéria.', 0, 'postimage/2021_12_13-12:16:10_Abuja (Tout corps d\'état)_img.crdownload', 'postimage/2021_12_13-12:16:10_Abuja (Tout corps d\'état)_imga.crdownload', 'postimage/2021_12_13-12:16:10_Abuja (Tout corps d\'état)_imgb.crdownload', 'postimage/2021_12_13-12:16:10_Abuja (Tout corps d\'état)_imgc.crdownload', 2, 2, '2021-12-13 19:16:10', '2021-12-13 19:16:10', NULL),
(8, 'Revêtement (Hôtel le DIPLOMATE)', NULL, 'revetement-hotel-le-diplomate', 'Projet de revêtement de l’hôtel le diplomate au Bénin.', 0, 'postimage/2021_12_13-12:18:43_Revêtement (Hôtel le DIPLOMATE)_img.jpg', 'postimage/2021_12_13-12:18:43_Revêtement (Hôtel le DIPLOMATE)_imga.jpg', 'postimage/2021_12_13-12:18:43_Revêtement (Hôtel le DIPLOMATE)_imgb.jpg', 'postimage/2021_12_13-12:18:43_Revêtement (Hôtel le DIPLOMATE)_imgc.jpg', 1, 3, '2021-12-13 19:18:43', '2021-12-13 19:18:43', NULL),
(9, 'Revêtement (immeuble Bolloré)', NULL, 'revetement-immeuble-bollore', 'Projet de revêtement de l\'immeuble Bolloré du Bénin.', 0, 'postimage/2021_12_13-12:18:48_Revêtement (immeuble Bolloré)_img.crdownload', 'postimage/2021_12_13-12:18:48_Revêtement (immeuble Bolloré)_imga.crdownload', 'postimage/2021_12_13-12:18:48_Revêtement (immeuble Bolloré)_imgb.crdownload', 'postimage/2021_12_13-12:18:48_Revêtement (immeuble Bolloré)_imgc.crdownload', 2, 3, '2021-12-13 19:18:48', '2021-12-13 19:18:48', NULL),
(10, 'Pavage MEDEDJONOU', NULL, 'pavage-mededjonou', 'Projet de pavage et \'assainissement de MEDEDJONOU ( Bénin )', 0, 'postimage/2021_12_13-12:21:40_Pavage MEDEDJONOU_img.crdownload', 'postimage/2021_12_13-12:21:40_Pavage MEDEDJONOU_imga.crdownload', 'postimage/2021_12_13-12:21:40_Pavage MEDEDJONOU_imgb.crdownload', 'postimage/2021_12_13-12:21:40_Pavage MEDEDJONOU_imgc.crdownload', 2, 5, '2021-12-13 19:21:40', '2021-12-13 19:21:40', NULL),
(11, 'CFP DOGBO', NULL, 'cfp-dogbo', 'Projet de construction du centre de formation de DOGBO au Bénin.', 0, 'postimage/2021_12_13-12:23:22_CFP DOGBO_img.jpg', 'postimage/2021_12_13-12:23:22_CFP DOGBO_imga.jpg', 'postimage/2021_12_13-12:23:22_CFP DOGBO_imgb.jpg', 'postimage/2021_12_13-12:23:22_CFP DOGBO_imgc.jpg', 1, 2, '2021-12-13 19:23:22', '2021-12-13 19:23:22', NULL),
(12, 'IMSP DANGBO', NULL, 'imsp-dangbo', 'Projet de construction de l’institut de mathématiques et des sciences au Bénin', 0, 'postimage/2021_12_13-12:23:25_IMSP DANGBO_img.crdownload', 'postimage/2021_12_13-12:23:25_IMSP DANGBO_imga.crdownload', 'postimage/2021_12_13-12:23:25_IMSP DANGBO_imgb.crdownload', 'postimage/2021_12_13-12:23:25_IMSP DANGBO_imgc.crdownload', 2, 2, '2021-12-13 19:23:25', '2021-12-13 19:23:25', NULL),
(13, 'REVETEMENT', NULL, 'revetement', 'Projet de revetement de l\'Africaine des assurance du Bénin.', 0, 'postimage/2021_12_13-12:25:03_REVETEMENT_img.crdownload', 'postimage/2021_12_13-12:25:03_REVETEMENT_imga.crdownload', 'postimage/2021_12_13-12:25:03_REVETEMENT_imgb.crdownload', 'postimage/2021_12_13-12:25:03_REVETEMENT_imgc.crdownload', 2, 2, '2021-12-13 19:25:03', '2021-12-13 19:25:03', NULL),
(14, 'Construction du siège ECOBANK Benin.', NULL, 'construction-du-siege-ecobank-benin', 'Projet de construction du siège ECOBANK Benin.', 0, 'postimage/2021_12_13-12:26:35_Construction du siège ECOBANK Benin._img.crdownload', 'postimage/2021_12_13-12:26:35_Construction du siège ECOBANK Benin._imga.crdownload', 'postimage/2021_12_13-12:26:35_Construction du siège ECOBANK Benin._imgb.crdownload', 'postimage/2021_12_13-12:26:35_Construction du siège ECOBANK Benin._imgc.crdownload', 2, 6, '2021-12-13 19:26:35', '2021-12-13 19:26:35', NULL),
(15, 'EFE Montaigne', NULL, 'efe-montaigne', 'Projet de construction de l’école Française au Bénin', 0, 'postimage/2021_12_13-12:27:18_EFE Montaigne_img.jpg', 'postimage/2021_12_13-12:27:18_EFE Montaigne_imga.jpg', 'postimage/2021_12_13-12:27:18_EFE Montaigne_imgb.jpg', 'postimage/2021_12_13-12:27:18_EFE Montaigne_imgc.jpg', 1, 2, '2021-12-13 19:27:18', '2021-12-13 19:27:18', NULL),
(16, 'Projet d\'assainissement de Avotrou (Bénin)', NULL, 'projet-dassainissement-de-avotrou-benin', 'Projet d\'assainissement de Avotrou (Bénin)\r\n\r\n\r\nProjet d\'assainissement de Avotrou (Bénin)', 0, 'postimage/2021_12_13-12:28:01_Projet d\'assainissement de Avotrou (Bénin)_img.crdownload', 'postimage/2021_12_13-12:28:01_Projet d\'assainissement de Avotrou (Bénin)_imga.crdownload', 'postimage/2021_12_13-12:28:01_Projet d\'assainissement de Avotrou (Bénin)_imgb.crdownload', 'postimage/2021_12_13-12:28:01_Projet d\'assainissement de Avotrou (Bénin)_imgc.crdownload', 2, 5, '2021-12-13 19:28:01', '2021-12-13 19:28:01', NULL),
(17, 'PROJET : CNSS', NULL, 'projet-cnss', 'Construction d\'un nouveau bâtiment au niveau de l\'agence CNSS Akpakpa', 0, 'postimage/2021_12_13-12:30:08_PROJET : CNSS_img.crdownload', 'postimage/2021_12_13-12:30:08_PROJET : CNSS_imga.crdownload', 'postimage/2021_12_13-12:30:08_PROJET : CNSS_imgb.crdownload', 'postimage/2021_12_13-12:30:08_PROJET : CNSS_imgc.crdownload', 2, 2, '2021-12-13 19:30:08', '2021-12-13 19:30:08', NULL),
(18, 'Atelier mécanique et centre de transfert des déchets solides ménagers', NULL, 'atelier-mecanique-et-centre-de-transfert-des-dechets-solides-menagers', 'Travaux de construction d’une unité composée d’un atelier mécanique et d’un centre de transfert des déchets solides ménagers d’Anguededou à Youpougon en Côte d’Ivoire', 0, 'postimage/2021_12_13-12:32:25_Atelier mécanique et centre de transfert des déchets solides ménagers_img.crdownload', 'postimage/2021_12_13-12:32:25_Atelier mécanique et centre de transfert des déchets solides ménagers_imga.crdownload', 'postimage/2021_12_13-12:32:25_Atelier mécanique et centre de transfert des déchets solides ménagers_imgb.crdownload', 'postimage/2021_12_13-12:32:25_Atelier mécanique et centre de transfert des déchets solides ménagers_imgc.crdownload', 2, 6, '2021-12-13 19:32:25', '2021-12-13 19:32:25', NULL),
(19, 'PROJET : BOLLORE', NULL, 'projet-bollore', 'Construction du bâtiment de BENIN TERMINAL pour le compte du Groupe BOLLORE en sous-traitance avec la Société SOGEA-SATOM  \r\n\r\nTravaux :\r\n\r\n- Lot 04 : Fourniture et pose de Faux-Plafond et\r\n-Lot 08 : Fourniture et pose de Revêtements sols et murs en carreaux\r\n\r\nNom du Maître de l\'Ouvrage : BOLLORE / SOGEA SATOM', 0, 'postimage/2021_12_13-12:33:38_PROJET : BOLLORE_img.jpg', 'postimage/2021_12_13-12:33:38_PROJET : BOLLORE_imga.jpg', 'postimage/2021_12_13-12:33:38_PROJET : BOLLORE_imgb.jpg', 'postimage/2021_12_13-12:33:38_PROJET : BOLLORE_imgc.jpg', 1, 2, '2021-12-13 19:33:38', '2021-12-13 19:33:38', NULL),
(20, 'BATIMENT SEME ONE', NULL, 'batiment-seme-one', 'Conception et réalisation des travaux de réhabilitation d\'un immeuble en bâtiment intelligent (prestation de génie civil, informatique, électronique et acoustiques connectées y compris le parking afférant)\r\nEn groupement avec les Entreprises : SP Construction - COMTEL et ABC Décibel\r\nTravaux de DYJESCK SA : Revêtement sol, peinture, Faux-plafond, Menuiserie bois, étanchéité, menuiserie alu, main courante.\r\nNom du Maître de l\'Ouvrage : Agence de Développement de Sèmè City (ADSC)', 0, 'postimage/2021_12_13-12:37:51_BATIMENT SEME ONE_img.jpg', 'postimage/2021_12_13-12:37:51_BATIMENT SEME ONE_imga.jpg', 'postimage/2021_12_13-12:37:51_BATIMENT SEME ONE_imgb.jpg', 'postimage/2021_12_13-12:37:51_BATIMENT SEME ONE_imgc.jpg', 1, 2, '2021-12-13 19:37:51', '2021-12-13 19:37:51', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('1HEI8IJlfFkuOAJEcSg9lqKOAu2kWnT0Kypls3Nu', NULL, '54.36.148.155', 'Mozilla/5.0 (compatible; AhrefsBot/7.0; +http://ahrefs.com/robot/)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRUg2WXBFZFJmWkZubG1SZENMc0Z5ajFtc0UxOEVTbFpvQWZodVpFciI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDk6Imh0dHBzOi8vZHlqZXNjay5jb20vP0xPU1M9ZXhhbXBsZXMta2V0b2dlbmljLWRpZXQiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19', 1639394596),
('AoLcKe4Vd4CmfZ2bhd08ZIOLVjytWHR1c3FIgjSg', NULL, '54.36.149.59', 'Mozilla/5.0 (compatible; AhrefsBot/7.0; +http://ahrefs.com/robot/)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZnk2ZUNYcnNwNXhRRzlmVEdWOTNaZElWbXVhZHpseEZ4QmhyVThhNCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDg6Imh0dHBzOi8vZHlqZXNjay5jb20vP0xPU1M9Ym9vay1vbi1rZXRvZ2VuaWMtZGlldCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1639394078),
('ARUId6MV7YAd0uYVZOa5enDcZO6dR6txXpJtVM5a', NULL, '160.119.146.197', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiSjBQTUZkMG1nSm0xSmk2NFJwYWJ3SThSUUpIUUVodHJMQUZsdVhOeiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vYmoubWFpbmZvLmJpeiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1639400052),
('azuqmATKWTzPLcYszNZqjHHjjDyBqTPU6870PpB5', 1, '160.119.146.197', 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:95.0) Gecko/20100101 Firefox/95.0', 'YTo3OntzOjY6Il90b2tlbiI7czo0MDoia1dJWkFRMzFLS2N3WDZvekZJY01aNjQ0cGJPeHhMQXh1NTJQd1AwbSI7czozOiJ1cmwiO2E6MDp7fXM6OToiX3ByZXZpb3VzIjthOjE6e3M6MzoidXJsIjtzOjg2OiJodHRwczovL2JqLm1haW5mby5iaXovcmVhbGlzYXRpb25zL3ZpbGxhZ2UtZGVuZmFudHMtc29zLWEteWFtb3Vzc291a3JvLWVuLWNvdGUtZGl2b2lyZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjE7czoxNzoicGFzc3dvcmRfaGFzaF93ZWIiO3M6NjA6IiQyeSQxMCRoTWFXUFl1S1R4d2Q3cm9qbUxtLjl1MnM5RlZkcVBVeDQ0Ump2NUFwd0J6U3dVVWFTaG10NiI7czoyMToicGFzc3dvcmRfaGFzaF9zYW5jdHVtIjtzOjYwOiIkMnkkMTAkaE1hV1BZdUtUeHdkN3Jvam1MbS45dTJzOUZWZHFQVXg0NFJqdjVBcHdCelN3VVVhU2htdDYiO30=', 1639400336),
('CzkacXe6QYFNBSX7dsUHTWorQmyuijtwROKuoD0D', NULL, '185.191.171.15', 'Mozilla/5.0 (compatible; SemrushBot/7~bl; +http://www.semrush.com/bot.html)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTGJ2bFdGektLdUM1RUdzWXRGMEU0RG5ZWVJ0S3h5WmhpWmRKcmtnMyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTI6Imh0dHBzOi8vZHlqZXNjay5jb20vP01hbGU9c2lsZGVuYWZpbC13aGF0LWRvZXMtaXQtZG8iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19', 1639394611),
('fYMsvlIXi9xJA1S3jDYxBdBjxP6K0JoAGn6UhDxs', NULL, '160.119.146.197', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.159 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoib1RHRUdmck5oTTJDTkwwWTdWdEhxb1dEazI5cXRLbzlySkhaMjRpeCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTk6Imh0dHBzOi8vZHlqZXNjay5jb20iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19', 1639394093),
('HQC9vtkBzufQgxdjNU6BIUOZVEQaR90kQM4kyXI4', NULL, '114.119.131.246', 'Mozilla/5.0 (Linux; Android 7.0;) AppleWebKit/537.36 (KHTML, like Gecko) Mobile Safari/537.36 (compatible; PetalBot;+https://webmaster.petalsearch.com/site/petalbot)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVnVwemdzaG5nMXJnYlJ1dFdFSzZPejlodUF5Zkw0NW41ZHExYkRDOSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTc6Imh0dHBzOi8vZHlqZXNjay5jb20vP0xPU1M9YmVzdC1mb3Itd2VpZ2h0LWxvc3Mtc3VwcGxlbWVudCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1639395135),
('IUxJbjPsmQDIiihw9tDlwu2xRwJPttgazk7KX0pe', NULL, '160.119.146.197', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.159 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiSnhPZHM0UFRBNnY3ZUhWM3hLM3A2a0wxbllaSkJQYWNTS1RKZnptNSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzI6Imh0dHBzOi8vZHlqZXNjay5jb20vcmVhbGlzYXRpb25zIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1639394042),
('jJJMoFFAqCX0Bef3FoRLleA6p9yzi5uqGH2QbevD', 2, '160.119.146.197', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.159 Safari/537.36', 'YTo2OntzOjY6Il90b2tlbiI7czo0MDoiUmU2WDlzYkhGZDNSNHZhOUNrN0Z4bTAwTVE3a3c3WHpVa0RNWTRPZiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDg6Imh0dHBzOi8vYmoubWFpbmZvLmJpei9yZWFsaXNhdGlvbnMvZWZlLW1vbnRhaWduZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjI7czoxNzoicGFzc3dvcmRfaGFzaF93ZWIiO3M6NjA6IiQyeSQxMCQ4aERQendNSnVEc0M4SC5aeDE0R0dPdFNaZHhpZDhxUFFOb2cvU0dUZ3VOMFE3QjBkRUVZVyI7czoyMToicGFzc3dvcmRfaGFzaF9zYW5jdHVtIjtzOjYwOiIkMnkkMTAkOGhEUHp3TUp1RHNDOEguWngxNEdHT3RTWmR4aWQ4cVBRTm9nL1NHVGd1TjBRN0IwZEVFWVciO30=', 1639400422),
('KaniBtybc650cQJ0IOGmqujYUQCKXSfjXwpPu9OJ', NULL, '160.119.146.197', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.159 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiOGRpbEtUYkVlNFBFM2tQR05HbG1mYUtiWUFJZ2ZOaDlRVEJicXBPeSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzI6Imh0dHBzOi8vZHlqZXNjay5jb20vcmVhbGlzYXRpb25zIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1639394339),
('liuDvcSSL781GrYKQnioS67pUjilqlybyLeiPT9k', NULL, '199.36.221.74', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.85 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiY1lhVU1UUHFBWm9EeGg2VWZBbk1ScWtVbVRLYlBhR3U3NlBjZXVlRSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjc6Imh0dHBzOi8vZHlqZXNjay5jb20vY29udGFjdCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1639395146),
('Mwqxz4J7n23rfcWc1A5YlsfzHaBr1uSZ6W0zIAyM', NULL, '160.119.146.197', 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:91.0) Gecko/20100101 Firefox/91.0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMzhNZ0xwNllEWTBHOFZEZ3NIVWxHZGpuNjVtc05NTGFQR3ZqN2FzQyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzI6Imh0dHBzOi8vZHlqZXNjay5jb20vcmVhbGlzYXRpb25zIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1639394289),
('q7wUDeGtqzyqFLXUxcLtpxe22M9djUuZAVAgZrwa', 1, '160.119.146.197', 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:95.0) Gecko/20100101 Firefox/95.0', 'YTo2OntzOjY6Il90b2tlbiI7czo0MDoiNDBWdFlVQ0hlNnlSUWtlanZVVzk1eGlvb2laWGEycnVIU1ZIUnRpcSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjk6Imh0dHBzOi8vZHlqZXNjay5jb20vY2F0ZWdvcmllIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6MTtzOjE3OiJwYXNzd29yZF9oYXNoX3dlYiI7czo2MDoiJDJ5JDEwJGhNYVdQWXVLVHh3ZDdyb2ptTG0uOXUyczlGVmRxUFV4NDRSanY1QXB3QnpTd1VVYVNobXQ2IjtzOjIxOiJwYXNzd29yZF9oYXNoX3NhbmN0dW0iO3M6NjA6IiQyeSQxMCRoTWFXUFl1S1R4d2Q3cm9qbUxtLjl1MnM5RlZkcVBVeDQ0Ump2NUFwd0J6U3dVVWFTaG10NiI7fQ==', 1639394837),
('U4yL72bXNXACStgfoasvFycjMnWruikU681st1yL', NULL, '54.36.148.251', 'Mozilla/5.0 (compatible; AhrefsBot/7.0; +http://ahrefs.com/robot/)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMXVGeTh3RllkbENSOU1Ldlk4bUpQRTNJZTRXQWFnMnM1aFE0Z2htTCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTU6Imh0dHBzOi8vZHlqZXNjay5jb20vP0xPU1M9YmVzdC13ZWlnaHQtbG9zcy1yZXRyZWF0cy11c2EiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19', 1639394887);

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `two_factor_secret` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `two_factor_recovery_codes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `current_team_id` bigint(20) UNSIGNED DEFAULT NULL,
  `profile_photo_path` varchar(2048) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `two_factor_secret`, `two_factor_recovery_codes`, `remember_token`, `current_team_id`, `profile_photo_path`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Banelsems', 'developpeur.02@mainfo.info', NULL, '$2y$10$hMaWPYuKTxwd7rojmLm.9u2s9FVdqPUx44Rjv5ApwBzSwUUaShmt6', NULL, NULL, NULL, NULL, NULL, '2021-12-13 18:18:13', '2021-12-13 18:18:13', NULL),
(2, 'Taïrou Baïssou', 'developpeur.03@mainfo.info', NULL, '$2y$10$8hDPzwMJuDsC8H.Zx14GGOtSZdxid8qPQNog/SGTguN0Q7B0dEEYW', NULL, NULL, NULL, NULL, NULL, '2021-12-13 18:39:24', '2021-12-13 18:39:24', NULL);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Index pour la table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Index pour la table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Index pour la table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT pour la table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
